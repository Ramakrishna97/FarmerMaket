using AutoMapper;
using CheckOutMicroService.Controllers;
using CheckOutMicroService.Models;
using CheckOutMicroService.Services;
using CheckOutMicroService.Services.Interfaces;
using Moq;

namespace CheckoutSystemTest
{
    [TestFixture]
    public class CheckoutServiceTests
    {
        private ICheckoutService checkoutService;
        private IMapper mapper;

        [SetUp]
        public void Setup()
        {
            checkoutService = new CheckoutService(new ProductService(new DiscountService(), mapper), new DiscountService());
        }

        [Test]
        public void Test1()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {
                  ProductCode =  "CF1",
                  Quantity = 5
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(28.08));

        }
        [Test]
        public void APPLTEST()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {

                      ProductCode =  "AP1",

                  Quantity = 5
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(22.50));
        }

        [Test]
        public void CHMKTEST()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {
                  ProductCode =  "CH1",
                  Quantity = 5
                },  // 3.11 * 5 = 15.55
                new BasketItem()
                {
                   ProductCode =  "MK1",
                   Quantity = 5
                }  // one milk free (5-1)*4.75 = 19.00
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(34.55)); // 15.55 + 19 = 34.55
        }

        [Test]
        public void OMALTEST()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {
                    ProductCode =  "AP1",
                  Quantity = 1
                },  // 6 * 0.5 = 3 
                 new BasketItem()
                 {
                   ProductCode =  "OM1",
                  Quantity = 1
                }  // 3.69
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(6.69));
        }

        [Test]
        public void TEST1()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {

                      ProductCode =  "CH1",
                      // discount price 4.50 , so 4.5*6 = 22.50
                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "AP1",
                     Quantity = 1
                } ,
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "MK1",

                  Quantity = 1
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(16.61));
        }

        [Test]
        public void TEST2()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                {

                      ProductCode =  "CH1",
                      // discount price 4.50 , so 4.5*6 = 22.50
                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "CF1",
                     Quantity = 1
                } ,
                new BasketItem()
                 {

                      ProductCode =  "MK1",

                  Quantity = 1
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(20.34));
        }

        [Test]
        public void TEST3()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "MK1",

                  Quantity = 1
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(10.75));
        }

        [Test]
        public void TEST4()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                 {

                      ProductCode =  "CF1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "CF1",

                  Quantity = 1
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(11.23));
        }
        [Test]
        public void TEST5()
        {
            var basketItems = new List<BasketItem>()
            {
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "CH1",

                  Quantity = 1
                },
                new BasketItem()
                 {

                      ProductCode =  "AP1",

                  Quantity = 1
                }
            };
            var result = checkoutService.CalculateTotalPrice(basketItems);
            Assert.That(result, Is.EqualTo(16.61));
        }
    }
}
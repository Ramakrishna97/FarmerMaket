﻿using AutoMapper;
using CheckOutMicroService.Models;

namespace CheckOutMicroService.Mappers
{
    public class ViewModelMappingProfile : Profile
    {

        public ViewModelMappingProfile()
        {
            CreateMap<Product, DiscountProductViewModel>();
        }
    }
}

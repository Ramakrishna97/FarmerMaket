using CheckOutMicroService.Models;
using CheckOutMicroService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CheckOutMicroService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CheckoutController : ControllerBase
    {
        private readonly ICheckoutService checkoutService;
        public CheckoutController(ICheckoutService _checkoutService)
        {
            this.checkoutService = _checkoutService;
        }


        /// <summary>
        /// This API calculates the final price of the basket
        /// </summary>
        /// <param name="basket"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CalcluatePrice")]
        public IActionResult CalcluatePrice(List<BasketItem> basket)
        {
            try
            {
                return Ok(checkoutService.CalculateTotalPrice(basket));
            }
            catch (Exception e)
            {
                throw ;
            }
            
        }

    }
}
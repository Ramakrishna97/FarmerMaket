﻿using AutoMapper;
using CheckOutMicroService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace CheckOutMicroService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService productService;
        public ProductController(IProductService _productService)
        {
            this.productService = _productService;
        }

        /// <summary>
        /// This API returns All the available products along with discount offers ,If discount offer exists
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetProducts")]
        public IActionResult GetProducts()
        {
            try
            {
                return Ok(productService.GetAllProductsWithDiscountOffers());
            }
            catch (Exception e)
            {
                throw;
            }

        }

    }
}

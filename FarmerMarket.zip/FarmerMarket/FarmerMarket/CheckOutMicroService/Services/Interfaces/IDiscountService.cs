﻿using CheckOutMicroService.Models;

namespace CheckOutMicroService.Services.Interfaces
{
    public interface IDiscountService
    {
        List<Discount> GetAllDiscountOffers();
        List<Discount> GetDiscountOffersByProductCodes(List<string> productCodes);
       decimal TotalDiscountAmount(List<BasketItemDetails> basketItems);
    }
}

﻿using CheckOutMicroService.Models;

namespace CheckOutMicroService.Services.Interfaces
{
    public interface IProductService
    {
        Product GetProductByCode(string productCode);
        List<Product> GetAllProducts();
        List<DiscountProductViewModel> GetAllProductsWithDiscountOffers();
    }
}

﻿using CheckOutMicroService.Models;

namespace CheckOutMicroService.Services.Interfaces
{
    public interface ICheckoutService
    {
        decimal CalculateTotalPrice(List<BasketItem> basketItems);
        void AddToBasket(string productCode, int quantity);
    }
}

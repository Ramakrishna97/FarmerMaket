﻿using AutoMapper;
using CheckOutMicroService.Models;
using CheckOutMicroService.Services.Interfaces;

namespace CheckOutMicroService.Services
{
    public class ProductService : IProductService
    {
        private IList<Product> products;
        private readonly IDiscountService discountService;
        private readonly IMapper mapper;
        public ProductService(IDiscountService _discountService, IMapper _mapper)
        {
            products = new List<Product>()
            {
                new Product(){ ProductCode = "CH1", ProductName = "Chai", Price = 3.11m  },
                new Product(){ ProductCode = "AP1", ProductName = "Apples", Price = 6.00m  },
                new Product(){ ProductCode = "CF1", ProductName = "Coffee", Price = 11.23m  },
                new Product(){ ProductCode = "MK1", ProductName = "Milk", Price = 4.75m  },
                new Product(){ ProductCode = "OM1", ProductName = "Oatmeal", Price = 3.69m  }
            };
            this.discountService = _discountService;
            this.mapper = _mapper;
        }

        public Product GetProductByCode(string productCode)
        {
            return products.FirstOrDefault(p => p.ProductCode == productCode);
        }

        public List<Product> GetAllProducts()
        {
            return products.ToList();
        }
        public List<DiscountProductViewModel> GetAllProductsWithDiscountOffers()
        {
            List<DiscountProductViewModel> discountProductViewModels = new List<DiscountProductViewModel>();
            var discountOffers = discountService.GetAllDiscountOffers();
            var products = GetAllProducts();
            if (discountOffers.Count > 0 && products.Count > 0)
            {
                discountProductViewModels = (from discount in discountOffers
                                             join product in products
                                             on discount.ProductCode equals product.ProductCode 
                                             select new DiscountProductViewModel()
                                             {
                                                 Price = product.Price,
                                                 ProductName = product.ProductName,
                                                 ProductCode = product.ProductCode,
                                                 DiscountPercentage = discount.DiscountPercentage,
                                                 DiscountPrice = discount.DiscountPrice,
                                                 MaximumOfferedQuantity = discount.MaximumOfferedQuantity,
                                                 IsDiscountAvailable = true,
                                                 MinimumQuantity = discount.MinimumQuantity,
                                                 OfferedProductCode = discount.OfferedProductCode
                                             }).ToList();
            }
            else if(products.Count > 0)
            {
                discountProductViewModels = mapper.Map<List<DiscountProductViewModel>>(products).ToList();
            }
            return discountProductViewModels;
        }
    }
}

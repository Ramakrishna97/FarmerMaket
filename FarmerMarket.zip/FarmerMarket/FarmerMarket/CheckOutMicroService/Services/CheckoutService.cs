﻿using CheckOutMicroService.Models;
using CheckOutMicroService.Services.Interfaces;

namespace CheckOutMicroService.Services
{
    public class CheckoutService : ICheckoutService
    {
        private readonly IProductService productService;
        private readonly IDiscountService discountService;
        private IList<BasketItemDetails> basket;
        public CheckoutService(IProductService _productService, IDiscountService _discountService)
        {
            this.productService = _productService;
            this.discountService = _discountService;
        }

        public void AddToBasket(string productCode, int quantity)
        {
            Product product = productService.GetProductByCode(productCode);
            if (product != null)
            {
                basket.Add(new BasketItemDetails { Product = product, Quantity = quantity });
            }
            else
            {
                throw new ArgumentException("Invalid product code.");
            }
        }
        public decimal CalculateTotalPrice(List<BasketItem> basketItems)
        {
            decimal totalPrice = 0m;

            if (basketItems.Count == 0)
                return totalPrice;

            //get basket details
            var basket = (from item in basketItems
                                     join product in productService.GetAllProducts()
                                     on item.ProductCode equals product.ProductCode
                                     group new { product, item }  by product.ProductCode into b
                                     select b).ToList();

            var basketItemDetails = basket.Select(s => new BasketItemDetails() {Product = s.FirstOrDefault()?.product , Quantity = s.Sum(q => q.item.Quantity)}).ToList();

            foreach (var item in basketItemDetails)
            {
                totalPrice += item.Product.Price * item.Quantity;
            }
            // Apply special discounts
            totalPrice -= discountService.TotalDiscountAmount(basketItemDetails);
            return Math.Round(totalPrice, 2);
        }
    }
}

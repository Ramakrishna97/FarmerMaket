﻿using CheckOutMicroService.Models;
using CheckOutMicroService.Services.Interfaces;

namespace CheckOutMicroService.Services
{
    public class DiscountService : IDiscountService
    {
        private List<Discount> discountOffers;
        public DiscountService()
        {
            discountOffers = new List<Discount> { 
              new Discount(){ ProductCode = "CF1" , DiscountPercentage = 0.5M ,  MinimumQuantity = 2 },
              new Discount() { ProductCode = "AP1" , DiscountPrice = 1.50M ,  MinimumQuantity = 3},
              new Discount() { ProductCode = "CH1" , DiscountPercentage = 1.0M ,  MinimumQuantity = 1 , MaximumOfferedQuantity = 1 ,OfferedProductCode = "MK1"},
              new Discount() { ProductCode = "OM1" , DiscountPercentage = 0.5M ,  MinimumQuantity = 1, MaximumOfferedQuantity = 1 , OfferedProductCode = "AP1"}
            };
        }

        public List<Discount> GetAllDiscountOffers()
        {
            return discountOffers;
        }
        public List<Discount> GetDiscountOffersByProductCodes(List<string> productCodes)
        {
            if (productCodes.Count > 0)
                return discountOffers.Where(d => productCodes.Contains(d.ProductCode) || productCodes.Contains(d.OfferedProductCode)).Distinct().ToList();
            else
                return new List<Discount>();
        }

        public decimal TotalDiscountAmount(List<BasketItemDetails> basketItems)
        {
            decimal discountAmount = 0;
            if (basketItems.Count == 0)
                return discountAmount;

            var productCodes = basketItems.Select(b => b.Product.ProductCode).ToList();
            var discountOffers = GetDiscountOffersByProductCodes(productCodes);
            if (discountOffers.Count > 0)
            {
                foreach (Discount offer in discountOffers)
                {
                    if (offer != null)
                    {
                        var discountItem = basketItems.FirstOrDefault(b => b.Product.ProductCode == offer.ProductCode && b.Quantity >= offer.MinimumQuantity);
                        if (discountItem != null)
                        {

                            if (!string.IsNullOrEmpty(offer.OfferedProductCode))
                            {
                                var offeredItem = basketItems.FirstOrDefault(b => b.Product.ProductCode == offer.OfferedProductCode);
                                if (offeredItem == null)
                                {
                                    continue;
                                }
                                discountAmount += DiscountOnProduct(offer, offeredItem);
                            }
                            else
                            {
                                discountAmount += DiscountOnProduct(offer, discountItem);
                            }
                        }
                      
                    }
                }
            }
            return discountAmount;


        }

        /// <summary>
        /// This method returns the final discount of an item 
        /// </summary>
        /// <param name="offer"></param>
        /// <param name="discountItem"></param>
        /// <returns></returns>
        private decimal DiscountOnProduct(Discount offer, BasketItemDetails? discountItem)
        {
            decimal discountAmount = 0;
            if (discountItem != null)
            {
                if (offer.MaximumOfferedQuantity != null)
                {
                    if (offer.DiscountPercentage != null)
                    {
                        discountAmount += Convert.ToDecimal(offer.DiscountPercentage * discountItem.Product.Price * offer.MaximumOfferedQuantity);
                    }
                    else if (offer.DiscountPrice != null)
                    {
                        discountAmount += Convert.ToDecimal(offer.DiscountPrice * offer.MaximumOfferedQuantity);
                    }
                }
                else
                {
                    if (offer.DiscountPercentage != null)
                    {
                        discountAmount += Convert.ToDecimal(offer.DiscountPercentage * discountItem.Product.Price * discountItem.Quantity);
                    }
                    if (offer.DiscountPrice != null)
                    {
                        discountAmount += Convert.ToDecimal(offer.DiscountPrice * discountItem.Quantity);
                    }

                }
            }
            return discountAmount;
        }
    }
}

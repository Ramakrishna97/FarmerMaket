﻿namespace CheckOutMicroService.Models
{
    public class Product
    {
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }

        public bool IsDiscountAvailable { get; set; }
    }

    public class DiscountProductViewModel : Product
    {
        public decimal? DiscountPercentage { get; set; }
        public int? MinimumQuantity { get; set; }
        public int? MaximumOfferedQuantity { get; set; }
        public string OfferedProductCode { get; set; }

        public decimal? DiscountPrice { get; set; }
    }

}

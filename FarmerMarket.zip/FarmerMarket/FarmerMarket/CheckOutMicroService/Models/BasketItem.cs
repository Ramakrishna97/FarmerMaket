﻿namespace CheckOutMicroService.Models
{
    public class BasketItemDetails
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }
    public class BasketItem
    {
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
    }
}

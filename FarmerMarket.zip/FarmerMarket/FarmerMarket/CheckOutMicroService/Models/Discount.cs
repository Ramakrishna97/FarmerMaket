﻿namespace CheckOutMicroService.Models
{
    public class Discount
    {
        public string ProductCode { get; set; }
        public decimal? DiscountPercentage { get; set; }
        public int?  MinimumQuantity{ get; set; }
        public int?  MaximumOfferedQuantity{ get; set; }
        public string OfferedProductCode { get; set; }

        public decimal? DiscountPrice { get; set; }
    }

}
